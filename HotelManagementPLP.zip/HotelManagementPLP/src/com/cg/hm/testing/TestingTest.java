package com.cg.hm.testing;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestingTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
